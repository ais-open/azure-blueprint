﻿configuration PDCBaselineDSC
{
   param
   (
        ### Create AD PDC ###
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30,

        ### Configure Antimalware ###
        [string]$IsSingleInstance = "Yes",
		[bool]$CheckForSignaturesBeforeRunningScan,
		[bool]$DisableArchiveScanning,
		[bool]$DisableAutoExclusions,
		[bool]$DisableBehaviorMonitoring,
		[bool]$DisableCatchupFullScan,
		[bool]$DisableCatchupQuickScan,
		[bool]$DisableEmailScanning,
		[bool]$DisableIntrusionPreventionSystem,
		[bool]$DisableIOAVProtection,
		[bool]$DisablePrivacyMode,
		[bool]$DisableRealtimeMonitoring,
		[bool]$DisableRemovableDriveScanning,
		[bool]$DisableRestorePoint,
		[bool]$DisableScanningMappedNetworkDrivesForFullScan,
		[bool]$DisableScanningNetworkFiles,
		[bool]$DisableScriptScanning,
		[string[]]$ExclusionExtension,
	    [string[]]$ExclusionPath,
		[string[]]$ExclusionProcess,	
		[ValidateSet("Allow","Block","Clean","NoAction","Quarantine","Remove","UserDefined")]
		[string]$HighThreatDefaultAction,
		[ValidateSet("Allow","Block","Clean","NoAction","Quarantine","Remove","UserDefined")]
		[string]$LowThreatDefaultAction,
		[ValidateSet("Advanced","Basic","Disabled")]
		[string]$MAPSReporting,
		[ValidateSet("Allow","Block","Clean","NoAction","Quarantine","Remove","UserDefined")]
		[string]$ModerateThreatDefaultAction,
		[UInt32]$QuarantinePurgeItemsAfterDelay,
		[bool]$RandomizeScheduleTaskTimes,
		[ValidateSet("Both","Incoming","Outcoming")]
		[string]$RealTimeScanDirection,
		[ValidateSet("Everyday","Friday","Monday","Never","Saturday","Sunday","Thursday","Tuesday","Wednesday")]
		[string]$RemediationScheduleDay,
		[DateTime]$RemediationScheduleTime,
		[UInt32]$ReportingAdditionalActionTimeOut,
		[UInt32]$ReportingCriticalFailureTimeOut,
		[UInt32]$ReportingNonCriticalTimeOut,
		[UInt32]$ScanAvgCPULoadFactor,
		[bool]$ScanOnlyIfIdleEnabled,
		[ValidateSet("FullSCan","QuickScan")]
		[string]$ScanParameters,
		[UInt32]$ScanPurgeItemsAfterDelay,
		[ValidateSet("Everyday","Friday","Monday","Never","Saturday","Sunday","Thursday","Tuesday","Wednesday")]
		[string]$ScanScheduleDay,
		[DateTime]$ScanScheduleQuickScanTime,
		[DateTime]$ScanScheduleTime,
		[ValidateSet("Allow","Block","Clean","NoAction","Quarantine","Remove","UserDefined")]
		[string]$SevereThreatDefaultAction,
		[UInt32]$SignatureAuGracePeriod,
		[string]$SignatureDefinitionUpdateFileSharesSources,
		[bool]$SignatureDisableUpdateOnStartupWithoutEngine,
		[string]$SignatureFallbackOrder,
		[UInt32]$SignatureFirstAuGracePeriod,
		[ValidateSet("Everyday","Friday","Monday","Never","Saturday","Sunday","Thursday","Tuesday","Wednesday")]
		[string]$SignatureScheduleDay,
		[DateTime]$SignatureScheduleTime,
		[UInt32]$SignatureUpdateCatchupInterval,
		[UInt32]$SignatureUpdateInterval,
		[ValidateSet("Always","Never","None")]
		[string]$SubmitSamplesConsent,
		[ValidateSet("Allow","Block","Clean","NoAction","Quarantine","Remove","UserDefined")]
		[string]$ThreatIDDefaultAction_Actions,
		[UInt64]$ThreatIDDefaultAction_Ids,
		[bool]$UILockdown,
		[ValidateSet("Allow","Block","Clean","NoAction","Quarantine","Remove","UserDefined")]
		[string]$UnknownThreatDefaultAction,
[Parameter(Mandatory)]
        [String]$MachineName,

        [Parameter(Mandatory)]
        [String]$ResourceGroupName,

        [Parameter(Mandatory)]
        [String]$AutomationAccountName,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullorEmpty()]
        [PSCredential]
        $AzureAuthCreds,

        [Parameter(Mandatory)]
        [String]$SubscriptionId,

        [Parameter(Mandatory)]
        [String]$EnvironmentName
    ) 

    Write-Host "Check Module exists"
     Install-Packageprovider -Name Nuget -MinimumVersion 2.8.5.201 -Force
   
    
    # Add and update modules on the Automation account
    Write-Output "Importing necessary modules..."

    # Create a list of the modules necessary to register a hybrid worker
    $AzureRmModule = @{"Name" = "AzureRM"; "Version" = ""}
    $Modules = @($AzureRmModule)

    # Import modules
    foreach ($Module in $Modules) {
        $ModuleName = $Module.Name
        # Find the module version
        if ([string]::IsNullOrEmpty($Module.Version)){            
            # Find the latest module version if a version wasn't provided
            $ModuleVersion = (Find-Module -Name $ModuleName).Version
        } else {
            $ModuleVersion = $Module.Version
        }
        # Check if the required module is already installed
        $CurrentModule = Get-Module -Name $ModuleName -ListAvailable | where "Version" -eq $ModuleVersion
        if (!$CurrentModule) {

            $null = Install-Module -Name $ModuleName -RequiredVersion $ModuleVersion -Force
            Write-Output " Successfully installed version $ModuleVersion of $ModuleName..."
        } else {
            Write-Output " Required version $ModuleVersion of $ModuleName is installed..."
        }
    }

    Import-DscResource -ModuleName WindowsDefender -ModuleVersion "1.0.0.2"
    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, PSDesiredStateConfiguration
    Import-Module -Name AzureRM

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
       

        
   }
}