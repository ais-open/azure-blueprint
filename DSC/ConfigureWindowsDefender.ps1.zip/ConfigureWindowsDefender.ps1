Configuration ConfigureWindowsDefender
{
	param(
		[array]$ExclusionPaths,
		[array]$ExclusionExtensions,
		[array]$ExclusionProcesses,
		[bool]$DisableRealtimeMonitoring,
		[ValidateSet('Incoming','Outgoing','Both')]
		[string]$RealTimeScanDirection,
		$QuarantinePurgeItemsAfterDelay,
		$RemediationScheduleDay,
		$RemediationScheduleTime,
		$ReportingAdditionalActionTimeOut,
		$ReportingNonCriticalTimeOut,
		$ReportingCriticalFailureTimeOut,
		$ScanAvgCPULoadFactor,
		$CheckForSignaturesBeforeRunningScan,
		$ScanPurgeItemsAfterDelay,
		$ScanOnlyIfIdleEnabled,
		[ValidateSet('Everyday','Never','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')]
		[string]$ScanScheduleDay,
		$ScanScheduleQuickScanTime,
		$ScanScheduleTime,
		$SignatureFirstAuGracePeriod,
		$SignatureAuGracePeriod,
		$SignatureDefinitionUpdateFileSharesSources,
		$SignatureDisableUpdateOnStartupWithoutEngine,
		$SignatureDefinitionUpdateFileSharesSources,
		$SignatureFallbackOrder,
		$SignatureScheduleDay,
		$SignatureScheduleTime,
		$SignatureUpdateCatchupInterval,
		$SignatureUpdateInterval,
		$MAPSReporting,
		$DisablePrivacyMode,
		$RandomizeScheduleTaskTimes,
		$DisableBehaviorMonitoring,
		$DisableIntrusionPreventionSystem,
		$DisableIOAVProtection,
		$DisableRealtimeMonitoring,
		$DisableScriptScanning,
		$DisableArchiveScanning,
		$DisableAutoExclusions,
		$DisableCatchupFullScan,
		$DisableCatchupQuickScan,
		$DisableEmailScanning,
		$DisableRemovableDriveScanning,
		$DisableRestorePoint,
		$DisableScanningMappedNetworkDrivesForFullScan,
		$DisableScanningNetworkFiles,
		$UILockdown
	)

	Import-DscResource -ModuleName WindowsDefender

	Node localhost
	{
		LocalConfigurationManager
		{

		}
		Service WindowsDefender
		{
			Name = 'WinDefend'
			State = 'Running'
			Ensure = 'Present'
		}
		<#
		WindowsDefender SetExclusions
		{
			IsSingleInstance = "yes"
			ExclusionPath = $ExclusionPaths
			ExclusionExtension = $ExclusionExtensions
			ExclusionProcess = $ExclusionProcesses
			RealTimeScanDirection = $RealTimeScanDirection
			QuarantinePurgeItemsAfterDelay = $QuarantinePurgeItemsAfterDelay
			RemediationScheduleDay = $RemediationScheduleDay
			RemediationScheduleTime = $RemediationScheduleTime
			CheckForSignaturesBeforeRunningScan = $CheckForSignaturesBeforeRunningScan
			ScanScheduleDay = $ScanScheduleDay
			ScanScheduleQuickScanTime = $ScanScheduleQuickScanTime
			ScanScheduleTime = $ScanScheduleTime
			SignatureDisableUpdateOnStartupWithoutEngine = $SignatureDisableUpdateOnStartupWithoutEngine
			SignatureDefinitionUpdateFileSharesSources =  $SignatureDefinitionUpdateFileSharesSources
			SignatureUpdateInterval = $SignatureUpdateInterval
			RandomizeScheduleTaskTimes = $RandomizeScheduleTaskTimes
			DisableBehaviorMonitoring = $DisableBehaviorMonitoring
			DisableIntrusionPreventionSystem = $DisableIntrusionPreventionSystem
			DisableIOAVProtection = $DisableIOAVProtection
			DisableRealtimeMonitoring = $DisableRealtimeMonitoring
			DisableScriptScanning = $DisableScriptScanning
			DisableArchiveScanning = $DisableArchiveScanning
			DisableAutoExclusions = $DisableAutoExclusions
			DisableCatchupFullScan = $DisableCatchupFullScan
			DisableCatchupQuickScan = $DisableCatchupQuickScan
			DisableEmailScanning = $DisableEmailScanning
			DisableRemovableDriveScanning = $DisableRemovableDriveScanning
			DisableRestorePoint = $DisableRestorePoint
			DisableScanningMappedNetworkDrivesForFullScan = $DisableScanningMappedNetworkDrivesForFullScan
			DisableScanningNetworkFiles = $DisableScanningNetworkFiles
			UILockdown = $UILockdown
			DependsOn = "[Service]WindowsDefender"
		}
		#>
	}
}