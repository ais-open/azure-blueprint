Configuration ConfigureWindowsDefender
{
	Import-DscResource -ModuleName WindowsDefender

	Node localhost
	{
		LocalConfigurationManager
		{

		}
		Service WindowsDefender
		{
			Name = 'WinDefend'
			State = 'Running'
			Ensure = 'Present'
		}
		WindowsDefender SetParameters
		{
			IsSingleInstance = "yes"
			ExclusionPath = 'c:\Users'
			ExclusionExtension = '.txt'
			ExclusionProcess = 'w3wp.exe'
			RealTimeScanDirection = 'Both'
			RemediationScheduleDay = 'Everyday'			
			ScanScheduleDay = 'Everyday'
			DisableRealtimeMonitoring = $false
			#DependsOn = "[Service]WindowsDefender"
		}
	}
}